# require_relative "piece"
require "Singleton"

class NullPiece 
    

    include Singleton
   
    # def initialize
    # end

end